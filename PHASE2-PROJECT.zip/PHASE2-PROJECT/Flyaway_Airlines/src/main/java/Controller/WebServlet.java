package Controller;

public @interface WebServlet {

}
